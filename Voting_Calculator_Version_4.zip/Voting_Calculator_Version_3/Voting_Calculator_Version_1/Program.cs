﻿using System;
using System.Collections.Generic;

namespace Voting_Calculator_Version_1 
{
    class Program //Class implementation (OO feature). This is the default running class 
    {
        static void Main(string[] args) //Main is ran first
        {
            var CountryString = new string[] //Class implementation (OO feature). This is the list of country names
            {
            "Austria",
            "Belgium",
            "Bulgaria",
            "Croatia",
            "Cyprus",
            "Czech Republic",
            "Denmark",
            "Estonia",
            "Finland",
            "France",
            "Germany",
            "Greece",
            "Hungary",
            "Ireland",
            "Italy",
            "Latvia",
            "Lithuania",
            "Luxemborg",
            "Malta",
            "Netherlands",
            "Poland",
            "Portugal",
            "Romania",
            "Slovakia",
            "Slovenia",
            "Spain",
            "Sweden",
            };

            var CountryPopulationList = new double[] //Class implementation (OO feature). Double allows for decmial vlaue for the population of the countires
            {
               1.98,
               2.56,
               1.56,
               0.91,
               0.20,
               2.35,
               1.30,
               0.30,
               1.23,
               14.98,
               18.54,
               2.40,
               2.18,
               1.10,
               13.65,
               0.43,
               0.62,
               0.14,
               0.11,
               3.98,
               8.49,
               2.30,
               4.34,
               1.22,
               0.47,
               10.49,
               2.29,
            };

            List<Country> CountryList = new List<Country>(); //Object instantiation (OO feature)
            for (int i = 0; i < CountryString.Length; i++) //For every item in the string array
            {
                CountryList.Add(new Country(CountryString[i], CountryPopulationList[i])); //Object instantiation (OO feature). Create a object from that name
            }
            var acceptRegion = 0.55 * CountryList.Count; //Multiply 0.55 by the 27 countries, member states
            for (int i = 0; i < CountryList.Count; i++)
            {
                Console.WriteLine($"{VoteCalculator.yesVotes(CountryList).Item1} , {Math.Round(VoteCalculator.yesVotes(CountryList).Item2, 2)}"); //Method Call (OO feature). Goes through the list of countries and gathers all of the yes votes
                if (VoteCalculator.yesVotes(CountryList).Item1 > acceptRegion && VoteCalculator.yesVotes(CountryList).Item2 > 65) //Method Call (OO feature). Goes through the yes votes in the country list, item1 = countries voted yes, item2 is the population
                {
                    Console.WriteLine("Final result Approved"); //The above and this creates the qualified majority voting rule
                }
                else
                {
                    Console.WriteLine("Final result Rejected");
                }
                Console.WriteLine("All Countries are participating");
                Console.WriteLine($"{CountryList[i].Name}, {CountryList[i].Population} \nPlease enter a vote option of Yes, No, Abstain"); //Outputs country list names, population and the string thats in quotes \n makes a newline
                var userinput = Console.ReadLine(); //Gets user input
                switch (userinput.ToLower()) //Switches with the information passed from the user.
                {
                    case "abstain": //Specified address 
                        CountryList[i].VoteOption = (int)Country.VoteOptions.Abstain; //This assigns the values to Yes, No and Abstain
                        break; //This passes the control to the next statement
                    case "no":
                        CountryList[i].VoteOption = (int)Country.VoteOptions.No; //Integer function is used as the enum function assigns the vote options
                        break;
                    default:
                        CountryList[i].VoteOption = (int)Country.VoteOptions.Yes; //Default vote is yes if vote is not chosen
                        break;
                }


                Console.Clear(); //Clears the information on screen to allow for new information to be presented
            }
            for(int i = 0; i < CountryList.Count; i++) //Iterate through the country list
            {
                Console.WriteLine($"{CountryList[i].Name}, {CountryList[i].Population}, {(Country.VoteOptions)CountryList[i].VoteOption}"); //Output the country names, population as well as the vote options
            }
        }
    }
}

