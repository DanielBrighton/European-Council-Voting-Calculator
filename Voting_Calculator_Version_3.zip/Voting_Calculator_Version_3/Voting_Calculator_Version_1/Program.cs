﻿using System;
using System.Collections.Generic;

namespace Voting_Calculator_Version_1 
{
    class Program //This is the default running class class implementation
    {
        static void Main(string[] args) //Main is ran first
        {
            string[] CountryString = new string[] //This is the list of country names and new class implementation (OO feature)
            {
            "Austria",
            "Belgium",
            "Bulgaria",
            "Croatia",
            "Cyprus",
            "Czech Republic",
            "Denmark",
            "Estonia",
            "Finland",
            "France",
            "Germany",
            "Greece",
            "Hungary",
            "Ireland",
            "Italy",
            "Latvia",
            "Lithuania",
            "Luxemborg",
            "Malta",
            "Netherlands",
            "Poland",
            "Portugal",
            "Romania",
            "Slovakia",
            "Slovenia",
            "Spain",
            "Sweden",
            };

            double[] CountryPopulationList = new double[] //Double allows for decmial vlaue for the population of the countires and new class implementation (OO feature)
            {
               1.98,
               2.56,
               1.56,
               0.91,
               0.20,
               2.35,
               1.30,
               0.30,
               1.23,
               14.98,
               18.54,
               2.40,
               2.18,
               1.10,
               13.65,
               0.43,
               0.62,
               0.14,
               0.11,
               3.98,
               8.49,
               2.30,
               4.34,
               1.22,
               0.47,
               10.49,
               2.29,
            };

            List<Country> CountryList = new List<Country>(); //This is a 
            for (int i = 0; i < CountryString.Length; i++) //For every item in the string array
            {
                CountryList.Add(new Country(CountryString[i], CountryPopulationList[i])); //Create a object from that name
            }
            var acceptRegion = 0.55 * CountryList.Count; //Multiply 0.55 by the 27 countries
            for (int i = 0; i < CountryList.Count; i++)
            {
                Console.WriteLine($"{VoteCalculator.yesVotes(CountryList).Item1} , {VoteCalculator.yesVotes(CountryList).Item2}"); //Goes through the list of countries and gathers all of the yes votes
                if (VoteCalculator.yesVotes(CountryList).Item1 > acceptRegion && VoteCalculator.yesVotes(CountryList).Item2 > 65) //Goes through the yes votes in the country list, item1 = countries voted yes, item2 is the population
                {
                    Console.WriteLine("Vote has been accepted"); //The above and this creates the qualified majority voting rule
                }
                else
                {
                    Console.WriteLine("Vote has been rejected");
                }
                Console.WriteLine($"{CountryList[i].Name}, {CountryList[i].Population} \nPlease enter a vote option of Yes, No, Abstain"); //Outputs country list names, population and the string thats in quotes \n makes a newline
                string userinput = Console.ReadLine(); //Gets user input
                switch (userinput.ToLower()) //Switches with the information passed from the user.
                {
                    case "abstain": //Specified address 
                        CountryList[i].voteOption = (int)Country.voteOptions.Abstain; //This assigns the values to Yes, No and Abstain
                        break; //This passes the control to the next statement
                    case "no":
                        CountryList[i].voteOption = (int)Country.voteOptions.No; //Integer function is used as the enum function assigns the vote options
                        break;
                    default:
                        CountryList[i].voteOption = (int)Country.voteOptions.Yes; //Default vote is yes if vote is not chosen
                        break;
                }


                Console.Clear(); //Clears the information on screen to allow for new information to be presented
            }
            for(int i = 0; i < CountryList.Count; i++) //Iterate through the country list
            {
                Console.WriteLine($"{CountryList[i].Name}, {CountryList[i].Population}, {(Country.voteOptions)CountryList[i].voteOption}"); //Output the country names , population as well as the vote options
            }
        }
    }
}

