﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Voting_Calculator_Version_1
{
    public class Country //Class implementation (OO feature)
    {
        //Data abstraction (OO feature). Abstraction of Countries. 
        public enum VoteOptions //enum is a enumeration for specific values
        {
            Yes, //Voting options
            No,
            Abstain
        }
        public int VoteOption { get; set; }
        public string Name { get; set; } //This is the country name
        private double _population; //Private so can't be accessed unless in the same class this is also known as a backing variable
        public double Population //Encapsulation (OO feature). Public access so the infromation can get aquired anywhere. To get or set the population value also is encapsulation as the information is held within it
        {
            get //This gets the backing variable
            {
                return _population; 
            }
            set { //This is the logic to set the backing variable
                if (value < 0) //If the value passed is less than 0, such as -1.57
                {
                    _population = 0; //The population sets to 0
                }
                else //The backing variable is set to the value
                {
                    _population = value; //The value that is passed to the population variable is set the backing varaiable _population
                }
            }
        }
        public Country(string newName, double newPopulation) //Double to deal with decimal point values
        {
            Name = newName; //String country.Name gets and sets
            Population = newPopulation; //Double country.Population gets and sets
        }
    }
}
