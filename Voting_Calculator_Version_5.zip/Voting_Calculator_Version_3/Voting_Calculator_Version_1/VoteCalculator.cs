﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
namespace Voting_Calculator_Version_1
{
    class VoteCalculator //Class implementation (OO feature)
    { //Data abstraction as only the yes votes are being shown to the user
        public static (double,decimal) yesVotes(List<Country> countries) //Beginning of Qualified Majority voting rule 
        { //Encapsulation (OO feature)
            var x = from country in countries //Variable to create from the individual country in the countries list.
                    where country.VoteOption == (int)Country.VoteOptions.Yes //Checks for the yes votes 
                    select country; //Selects the yes votes submitted

            double population = default; //Sets population to default value

            for(int i = 0; i < x.Count(); i++) //Increments the population with the population from the Program.CS
            {
                population += x.ElementAt(i).Population; //This creates an index
            }

            return (x.Count(),(decimal)population); //Returns the the count iteration for the votes
        }
    }
}
