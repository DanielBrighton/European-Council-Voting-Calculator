﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Voting_Calculator_Version_1
{
    class VoteCalculator
    {
    }
}
